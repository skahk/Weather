import { Component, OnInit } from '@angular/core';
import { ElecService } from '../elec.service';

@Component({
  selector: 'app-last',
  templateUrl: './last.component.html',
  styleUrls: ['./last.component.css']
})
export class LastComponent implements OnInit {
array1;
array2;
  constructor(service :ElecService) {
    this.array1=service.getarray1();
    this.array2=service.getarray2();
   }

  ngOnInit() {
  }
  cli()
  {
    
    document.getElementById("hid").style.display="block";
    document.getElementById("hid2").style.display="none";
  }
  cli2()
  {
   
    document.getElementById("hid").style.display="none";
    document.getElementById("hid2").style.display="block";
  }


}
