import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-newform',
  templateUrl: './newform.component.html',
  styleUrls: ['./newform.component.css']
})
export class NewformComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
lo(){
  alert('signed in');
}
back()
  {
    
  this.router.navigate(['']);
  }
}
